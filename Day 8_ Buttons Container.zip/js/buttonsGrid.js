function displayResult() {
    const steps = [4,1,2,7,5,3,8,9,6];
    var capt;
    for (var i=1;i<=9;i++){
      capt = document.getElementById("btn"+i).innerHTML;
      document.getElementById("btn"+i).innerHTML = steps[capt-1];
    }
}